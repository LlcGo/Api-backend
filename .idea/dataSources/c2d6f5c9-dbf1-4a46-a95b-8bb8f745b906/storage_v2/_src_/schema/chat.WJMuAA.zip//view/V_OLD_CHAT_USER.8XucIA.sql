create view V_OLD_CHAT_USER as
select distinct `FU`.`ID`        AS `FU_ID`,
                `FU`.`USER_CODE` AS `FU_USER_CODE`,
                `FU`.`USER_NAME` AS `FU_USER_NAME`,
                `AU`.`ID`        AS `AU_ID`,
                `AU`.`USER_CODE` AS `AU_USER_CODE`,
                `AU`.`USER_NAME` AS `AU_USER_NAME`
from ((`chat`.`CHAT_MSG` `CM` left join `chat`.`CHAT_USER` `FU` on ((`CM`.`CHART_FROM_ID` = `FU`.`ID`)))
         left join `chat`.`CHAT_USER` `AU` on ((`CM`.`CHART_ACCEPT_ID` = `AU`.`ID`)))
where ((`FU`.`ID` is not null) and (`AU`.`ID` is not null) and (`CM`.`CHART_CMD` = '3'));

-- comment on column V_OLD_CHAT_USER.FU_ID not supported: 主键

-- comment on column V_OLD_CHAT_USER.FU_USER_CODE not supported: 用户代码

-- comment on column V_OLD_CHAT_USER.FU_USER_NAME not supported: 用户昵称

-- comment on column V_OLD_CHAT_USER.AU_ID not supported: 主键

-- comment on column V_OLD_CHAT_USER.AU_USER_CODE not supported: 用户代码

-- comment on column V_OLD_CHAT_USER.AU_USER_NAME not supported: 用户昵称

